export const FACEBOOK_AUTH_LINK = 'https://localhost:5000/auth/facebook';
export const GOOGLE_AUTH_LINK = 'https://localhost:5000/auth/google';
