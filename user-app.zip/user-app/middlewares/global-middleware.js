const express = require('express');
//const logger = require('morgan');
//const cors = require('cors');
//const passport = require('passport');

//const { configureJWTStrategy } = require( './passport-jwt';

module.exports = function setGlobalMiddleware(app) {
    app.use(express.json());
    app.use(express.urlencoded({ extended: true }));
    // app.use(cors());
    //app.use(logger('dev'));
    //app.use(passport.initialize({ userProperty: 'currentUser' }));
    //configureJWTStrategy();
};