const express = require('express');
//import passport from 'passport';
const userController = require('../controllers/user')

const userRouter = express.Router();
userRouter.post('/signup', userController.signup);
//userRouter.post('/login', userController.login);
//userRouter.post('/test', passport.authenticate('jwt', { session: false }), userController.test);



exports.userRouter = userRouter;