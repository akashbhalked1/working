const express = require('express');
const { userRouter } = require('./user')

const restRouter = express.Router();
restRouter.use('/v1/users', userRouter);

module.exports = { restRouter };