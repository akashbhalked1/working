const express = require('express');
const mongoose = require('mongoose');
const restRouter = require('./routers');
const devConfig = require('./config/env/development');
//const setGlobalMiddleware = require('./middlewares/global-middleware');
const router = express.Router();
mongoose.Promise = global.Promise;
//mongoose.connect(`mongodb://localhost/${devConfig.database}`);
mongoose.connect('mongodb://127.0.0.1:27017/mydb')
const app = express();
const PORT = devConfig.port;
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// register global middleware
//setGlobalMiddleware(app);
router.use('/api', restRouter);
app.use((req, res, next) => {
    const error = new Error('Not found');
    error.message = 'Invalid route';
    error.status = 404;
    next(error);
});
app.use((error, req, res, next) => {
    res.status(error.status || 500);
    return res.json({
        error: {
            message: error.message,
        },
    });
});

app.listen(PORT, () => {
    console.log(`Server is running at PORT ${PORT}`);
});