module.exports.devConfig = {
    port: 3000,
    database: 'mydb',
    secret: 'AHSDEUIYEIUER',
};