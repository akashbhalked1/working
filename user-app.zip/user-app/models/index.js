const UserModule = require('./user.js');
console.log("module/index")
module.exports = {
    UserModule
}