var mongoose = require('mongoose'),
    Schema = mongoose.Schema

var userSchema = Schema({
    first_name: {
        type: String,
        required: true
    },
    middle_name: {
        type: String,
        required: false
    },
    last_name: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true,
        unique: true
    },
    email: {
        type: String,
        required: false,
        unique: false,
        sparse: true
    },
    role: {
        type: String,
        required: false
    },
    address: {
        house_no: {
            type: String,
            required: true
        },
        street: {
            type: String,
            required: true
        },
        area: {
            type: String,
            required: true
        },
        landmark: {
            type: String,
            required: false
        },
        city: {
            type: String,
            required: true
        },
        state: {
            type: String,
            required: true
        },
        postal_code: {
            type: String,
            required: true
        }
    },
    date_created: {
        type: String,
        required: true,
        unique: true
    },
    date_modified: {
        type: String,
        required: true,
        unique: true
    }
});
var User = mongoose.model('User', userSchema);


module.exports = { User };