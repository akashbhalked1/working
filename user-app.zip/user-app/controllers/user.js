/* //const { User } = require('../models/user.js')
//const database = require('../config/database')
const cmsLibrary = require('cms-library')


const addUser = async(reqBody, callback) => {
    // let first_name = reqBody.first_name
    // let middle_name = reqBody.middle_name
    // let last_name = reqBody.last_name
    // let email = reqBody.email
    // let phone = reqBody.phone
    // let role = reqBody.role
    // let address = reqBody.address
    // let date_created = reqBody.date_created
    // let date_modified = reqBody.date_modified
    // let house_no = address.house_no
    // let street = address.street
    // let area = address.area
    // let landmark = address.landmark
    // let city = address.city
    // let state = address.state
    // let postal_code = address.postal_code
    //let user = await User.findOne({ phone });
    // let appObj = {}
    // appObj.dbUrl = database.url;
    // appObj.dbSchema = User;
    // appObj.data = {
    //     "first_name": "Sunildatta",
    //     "middle_name": "P",
    //     "last_name": "Kulkarni",
    //     "phone": "1234567895",
    //     "email": "sunil1121@sunil.com",
    //     "role": "admin"
    // };
    // let dbUrl = "mongodb://localhost/mydb";
    // let dbSchema = {
    //     firstName: {
    //         type: String,
    //         required: true
    //     },
    //     phone: {
    //         type: String,
    //         required: true
    //     }
    // };
    // let data = {
    //     "firstName": "Akash",
    //     "phone": "7760226727"
    // }
    // let appObj = {}
    // appObj.dbUrl = dbUrl;
    // appObj.dbSchema = dbSchema;
    // appObj.data = data;
    // cmsLibrary.createUser(appObj, (err, data) => {
    //     console.log("err", err)
    //     console.log("data", data)
    //     if (err) {
    //         return callback(err, 500, null)
    //     } else {
    //         return callback(null, 200, data)
    //     }
    // })
    var userLibrary = require('cms-library');
    let dbUrl = "mongodb://localhost/mydb";
    let dbSchema = {
        firstName: {
            type: String,
            required: true
        },
        phone: {
            type: String,
            required: true
        }
    };
    let data = {
        "firstName": "Akash",
        "phone": "7760226728"
    }
    let appObj = {}
    appObj.dbUrl = dbUrl;
    appObj.dbSchema = dbSchema;
    appObj.data = data;
    userLibrary.createUser(appObj, (err, resp) => {
        if (err) {
            //console.log("error", err);
            return callback(err, 500, null)
        } else {
            //console.log("response", resp);
            return callback(err, 200, resp)
        }
    });

    // if (user) {
    //     return callback('User already registered!', 400, null);
    // }
    // let newUser = new User({
    //     first_name,
    //     middle_name,
    //     last_name,
    //     phone,
    //     email,
    //     role,
    //     address: {
    //         house_no,
    //         street,
    //         area,
    //         landmark,
    //         city,
    //         state,
    //         postal_code
    //     },
    //     date_created,
    //     date_modified
    // })

    // newUser.save()
    //     .then(user => {
    //         console.log("newUser.save")
    //         return callback(null, 200, { status: "success", activated: user.activated, username: user.first_name, phone: user.phone })
    //     })
    //     .catch(e => {
    //         console.log("newUser catch")
    //         return callback(e.toString(), 500, null)
    //     })
}
 */


const {
    BAD_REQUEST,
    INTERNAL_SERVER_ERROR,
    UNAUTHORIZED
} = require('http-status-codes');
const bcryptjs = require('bcryptjs')
const jwt = require('jsonwebtoken')
const user_module = require('user-module')
const { devConfig } = require('../config/env/development')

exports.signup = async function(req, res) {
    try {
        // const { error, value } = userService.validateSchema(req.body);
        // if (error && error.details) {
        //     return res.status(BAD_REQUEST).json(error);
        // }
        user_module.user.addUser(req.body, (err, data) => {
            if (err) {
                return res.status(BAD_REQUEST).json(error);
            } else {
                return res.json({ success: true, message: 'User created successfully' });
            }
        });
        // const user = await User.create(value);
        return res.json({ success: true, message: 'User created successfully' });
    } catch (err) {
        console.error(err);
        return res.status(INTERNAL_SERVER_ERROR).json(err);
    }
}

exports.login = async function(req, res) {
    try {
        // const { error, value } = userService.validateSchema(req.body);
        // if (error && error.details) {
        //     return res.status(BAD_REQUEST).json(error);
        // }
        const user = await User.findOne({ email: value.email });
        if (!user) {
            return res
                .status(BAD_REQUEST)
                .json({ err: 'invalid email or password' });
        }
        const matched = await bcryptjs.compare(value.password, user.password);
        if (!matched) {
            return res.status(UNAUTHORIZED).json({ err: 'invalid credentials' });
        }
        const token = jwt.sign({ id: user._id }, devConfig.secret, {
            expiresIn: '1d'
        });
        return res.json({ success: true, token });
    } catch (err) {
        console.error(err);
        return res.status(INTERNAL_SERVER_ERROR).json(err);
    }
};
// module.exports = {
//     login,
//     signup
// }